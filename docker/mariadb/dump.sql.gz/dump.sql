-- MySQL dump 10.15  Distrib 10.0.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	10.0.29-MariaDB-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `check_list`
--

DROP TABLE IF EXISTS `check_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `content` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `securityCheck_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `check_list`
--

LOCK TABLES `check_list` WRITE;
/*!40000 ALTER TABLE `check_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `businessNumber` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `companySize` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `endDate` datetime(6) DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mainPhone` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `participantingStaft` int(11) NOT NULL,
  `participationBusiness` bigint(20) NOT NULL,
  `referenceDescription` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `representativeEmail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `representativeName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  `endDate` datetime(6) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `startDate` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentfile`
--

DROP TABLE IF EXISTS `documentfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentfile` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `fileName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileSize` float NOT NULL,
  `fileType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileUrl` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `objectId` bigint(20) DEFAULT NULL,
  `objectType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentfile`
--

LOCK TABLES `documentfile` WRITE;
/*!40000 ALTER TABLE `documentfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documentmetadata`
--

DROP TABLE IF EXISTS `documentmetadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `documentmetadata` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `contentLength` bigint(20) NOT NULL,
  `contentType` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fileLocation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salkey` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentmetadata`
--

LOCK TABLES `documentmetadata` WRITE;
/*!40000 ALTER TABLE `documentmetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `documentmetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `approverName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `approver_id` bigint(20) NOT NULL,
  `authorizationToUse` datetime(6) DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` bigint(20) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `directInputKind` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `endApproval` datetime(6) DEFAULT NULL,
  `endUse` datetime(6) DEFAULT NULL,
  `equipmentKind_id` bigint(20) NOT NULL,
  `noSerialNumber` bit(1) NOT NULL,
  `performerName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `performer_id` bigint(20) NOT NULL,
  `possession` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `projectName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` bigint(20) NOT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serialNumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startUse` datetime(6) DEFAULT NULL,
  `terminateType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `terminationRequest` datetime(6) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `useRequest` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_history`
--

DROP TABLE IF EXISTS `equipment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `equipment_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progressHistory` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment_history`
--

LOCK TABLES `equipment_history` WRITE;
/*!40000 ALTER TABLE `equipment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmentkind`
--

DROP TABLE IF EXISTS `equipmentkind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipmentkind` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `canInsert` bit(1) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `terminationMethodInCompany` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `terminationMethodParticipant` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmentkind`
--

LOCK TABLES `equipmentkind` WRITE;
/*!40000 ALTER TABLE `equipmentkind` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmentkind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `help`
--

DROP TABLE IF EXISTS `help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `help` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `help`
--

LOCK TABLES `help` WRITE;
/*!40000 ALTER TABLE `help` DISABLE KEYS */;
/*!40000 ALTER TABLE `help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invalidtoken`
--

DROP TABLE IF EXISTS `invalidtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invalidtoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `token` longtext COLLATE utf8_unicode_ci,
  `tokenStatus` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKaem6mmowxeubqc3wyeomj96ot` (`user_id`),
  CONSTRAINT `FKaem6mmowxeubqc3wyeomj96ot` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invalidtoken`
--

LOCK TABLES `invalidtoken` WRITE;
/*!40000 ALTER TABLE `invalidtoken` DISABLE KEYS */;
INSERT INTO `invalidtoken` VALUES (1,'2018-06-27 06:40:07.495000',1,'\0','2018-06-27 06:40:07.495000',1,'','eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiZGlyIn0..M_CS2WRQBVhbhNWN.-uSCuuaxSlY10mpq0iHPTWOfobrqik5Im6UgIdfKsSfjSubJE-a3jpLve7RrNNLEQ3lt_7HnQjqTAgWjLyNs2vpENtFGkFWQfb1VNOAk9qdD0RdYTpDDUMZLqwXgpjJivNSqJM3ZTLvt1LCT7yN4YIWXYLGQezUlAhE5zrhZJSaETaDTkxeEL3rErTvtiVfxX5U_VHGzew9mW-FhxYutkLwgRJFioMpRgPv7AXUP-q758whIPece6J3K6TZdKyZwh6XSZ5dWRXWa-I_S6oUQPfHrwNb3DfdqqW5c_UqX_LHz741Xv7tKgOziiAiy70qQEGzr1ODiSswQHiu6VSxLf_J5LPK1h_oGiy_Rh5iDZWWQUIi8UIlkrg_wXsCNd5pQItSo_f0.2UN4yM7iX0_EB6yYK2bAyA','LOGIN',1);
/*!40000 ALTER TABLE `invalidtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medial_file`
--

DROP TABLE IF EXISTS `medial_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medial_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medial_file`
--

LOCK TABLES `medial_file` WRITE;
/*!40000 ALTER TABLE `medial_file` DISABLE KEYS */;
/*!40000 ALTER TABLE `medial_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `dateOfShipment` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dayShippedEvery` int(11) NOT NULL,
  `expiryDate` datetime(6) DEFAULT NULL,
  `messageBody` longtext COLLATE utf8_unicode_ci,
  `nextRemindDate` datetime(6) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `sender_id` bigint(20) DEFAULT NULL,
  `shippingType` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_receiver`
--

DROP TABLE IF EXISTS `message_receiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message_receiver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `message_id` bigint(20) DEFAULT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `readFlag` bit(1) NOT NULL,
  `receiver_id` bigint(20) DEFAULT NULL,
  `relatedProject_id` bigint(20) DEFAULT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_receiver`
--

LOCK TABLES `message_receiver` WRITE;
/*!40000 ALTER TABLE `message_receiver` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_receiver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `approveDate` datetime(6) DEFAULT NULL,
  `approverName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `approver_id` bigint(20) DEFAULT NULL,
  `companyName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  `deadline` datetime(6) DEFAULT NULL,
  `details` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `performerName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `performer_id` bigint(20) DEFAULT NULL,
  `productName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `productRegistrationDate` datetime(6) DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `projectName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `statusNotification` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_history`
--

DROP TABLE IF EXISTS `product_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `progress` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progressHistory` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_history`
--

LOCK TABLES `product_history` WRITE;
/*!40000 ALTER TABLE `product_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project`
--

DROP TABLE IF EXISTS `project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `availableIPRangeFrom` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `availableIPRangeTo` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `endDate` datetime(6) DEFAULT NULL,
  `participantsStaft` int(11) NOT NULL,
  `participatingCompany` bigint(20) NOT NULL,
  `performSecurityReview` bit(1) NOT NULL,
  `progressRate` float NOT NULL,
  `progressStep` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `projectName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `staftHaveSPName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `staftHaveSecurityPledge` int(11) NOT NULL,
  `staftNoSPName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `startDate` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project`
--

LOCK TABLES `project` WRITE;
/*!40000 ALTER TABLE `project` DISABLE KEYS */;
/*!40000 ALTER TABLE `project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_admin`
--

DROP TABLE IF EXISTS `project_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_admin` (
  `project_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`project_id`,`user_id`),
  KEY `FKps4i8coybwsyghws4ulu3cnr3` (`user_id`),
  CONSTRAINT `FKhwqdy6kbc6g50o6dqig2g2hrd` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`),
  CONSTRAINT `FKps4i8coybwsyghws4ulu3cnr3` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_admin`
--

LOCK TABLES `project_admin` WRITE;
/*!40000 ALTER TABLE `project_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receiver`
--

DROP TABLE IF EXISTS `receiver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receiver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `message_id` bigint(20) DEFAULT NULL,
  `receiver_id` bigint(20) DEFAULT NULL,
  `relatedProject_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receiver`
--

LOCK TABLES `receiver` WRITE;
/*!40000 ALTER TABLE `receiver` DISABLE KEYS */;
/*!40000 ALTER TABLE `receiver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resettoken`
--

DROP TABLE IF EXISTS `resettoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resettoken` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resettoken`
--

LOCK TABLES `resettoken` WRITE;
/*!40000 ALTER TABLE `resettoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `resettoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `roleType` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'2018-06-27 06:40:04.849000',1,'\0','2018-06-27 06:40:04.849000',1,'Super Admin','SUPER_ADMIN'),(2,'2018-06-27 06:40:04.874000',1,'\0','2018-06-27 06:40:04.874000',1,'사업계획자','PROJECT_ADMIN'),(3,'2018-06-27 06:40:04.879000',1,'\0','2018-06-27 06:40:04.879000',1,'사업관리자','PROJECT_ADMIN'),(4,'2018-06-27 06:40:04.884000',1,'\0','2018-06-27 06:40:04.884000',1,'사업계획/관리자','PROJECT_ADMIN'),(5,'2018-06-27 06:40:04.889000',1,'\0','2018-06-27 06:40:04.889000',1,'보안담당자(부서별 대표)','SECURITY_MANAGER'),(6,'2018-06-27 06:40:04.893000',1,'\0','2018-06-27 06:40:04.893000',1,'관리자','PROJECT_MANAGER'),(7,'2018-06-27 06:40:04.899000',1,'\0','2018-06-27 06:40:04.899000',1,'개발자','WORKER'),(8,'2018-06-27 06:40:04.904000',1,'\0','2018-06-27 06:40:04.904000',1,'디자이너','WORKER'),(9,'2018-06-27 06:40:04.909000',1,'\0','2018-06-27 06:40:04.909000',1,'기획자','WORKER'),(10,'2018-06-27 06:40:04.914000',1,'\0','2018-06-27 06:40:04.914000',1,'퍼블리셔','WORKER'),(11,'2018-06-27 06:40:04.920000',1,'\0','2018-06-27 06:40:04.920000',1,'세일즈','WORKER');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_power`
--

DROP TABLE IF EXISTS `role_power`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_power` (
  `role_id` bigint(20) NOT NULL,
  `powers` longtext COLLATE utf8_unicode_ci,
  KEY `FK58rlrrrlp91xr76b0s24nc6nf` (`role_id`),
  CONSTRAINT `FK58rlrrrlp91xr76b0s24nc6nf` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_power`
--

LOCK TABLES `role_power` WRITE;
/*!40000 ALTER TABLE `role_power` DISABLE KEYS */;
INSERT INTO `role_power` VALUES (1,'securitycheck:list,securitycheck:add,securitycheck:update,securitycheck:view,securitycheck:delete'),(1,'help:list,help:add,help:update,help:view,help:delete'),(1,'equipment:list,equipment:view,equipment:confirmusage,equipment:confirmtermination,equipment:add,equipment:update,equipment:view,equipment:delete,equipment:requesttermination'),(1,'project:list,project:add,project:update,project:view,project:delete'),(1,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(1,'product:list,product:add,product:update,product:view,product:delete,product:confirm'),(1,'message:list,message:add,message:view,message:delete'),(1,'company:list,company:add,company:update,company:view,company:delete'),(1,'securityeducation:list,securityeducation:add,securityeducation:update,securityeducation:view,securityeducation:confirmcompletion,securityeducation:registercompletion,securityeducation:confirmrequest'),(1,'employee:list,employee:add,employee:update,employee:view,employee:delete'),(1,'setting:view,setting:update'),(1,'role:list,role:add,role:update,role:view,role:delete'),(1,'equipmentkind:list,equipmentkind:add,equipmentkind:update,equipmentkind:view,equipmentkind:delete'),(1,'employer:list,employer:add,employer:update,employer:view,employer:delete'),(1,'securityviolation:list,securityviolation:add,securityviolation:update,securityviolation:view,securityviolation:delete'),(2,'securitycheck:list,securitycheck:add,securitycheck:update,securitycheck:view,securitycheck:delete'),(2,'project:list,project:add,project:update,project:view,project:delete'),(2,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(2,'product:list,product:add,product:update,product:view,product:delete,product:confirm'),(2,'message:list,message:add,message:view,message:delete'),(2,'company:list,company:add,company:update,company:view,company:delete'),(2,'securityeducation:list,securityeducation:add,securityeducation:update,securityeducation:view,securityeducation:confirmcompletion,securityeducation:registercompletion,securityeducation:confirmrequest'),(2,'employee:list,employee:add,employee:update,employee:view,employee:delete'),(2,'help:list,help:view'),(2,'role:list,role:add,role:update,role:view,role:delete'),(2,'equipmentkind:list,equipmentkind:add,equipmentkind:update,equipmentkind:view,equipmentkind:delete'),(2,'securityviolation:list,securityviolation:add,securityviolation:update,securityviolation:view,securityviolation:delete'),(2,'equipment:list,equipment:view,equipment:confirmusage,equipment:confirmtermination'),(3,'securitycheck:list,securitycheck:add,securitycheck:update,securitycheck:view,securitycheck:delete'),(3,'project:list,project:add,project:update,project:view,project:delete'),(3,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(3,'product:list,product:add,product:update,product:view,product:delete,product:confirm'),(3,'message:list,message:add,message:view,message:delete'),(3,'company:list,company:add,company:update,company:view,company:delete'),(3,'securityeducation:list,securityeducation:add,securityeducation:update,securityeducation:view,securityeducation:confirmcompletion,securityeducation:registercompletion,securityeducation:confirmrequest'),(3,'employee:list,employee:add,employee:update,employee:view,employee:delete'),(3,'help:list,help:view'),(3,'role:list,role:add,role:update,role:view,role:delete'),(3,'equipmentkind:list,equipmentkind:add,equipmentkind:update,equipmentkind:view,equipmentkind:delete'),(3,'securityviolation:list,securityviolation:add,securityviolation:update,securityviolation:view,securityviolation:delete'),(3,'equipment:list,equipment:view,equipment:confirmusage,equipment:confirmtermination'),(4,'securitycheck:list,securitycheck:add,securitycheck:update,securitycheck:view,securitycheck:delete'),(4,'project:list,project:add,project:update,project:view,project:delete'),(4,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(4,'product:list,product:add,product:update,product:view,product:delete,product:confirm'),(4,'message:list,message:add,message:view,message:delete'),(4,'company:list,company:add,company:update,company:view,company:delete'),(4,'securityeducation:list,securityeducation:add,securityeducation:update,securityeducation:view,securityeducation:confirmcompletion,securityeducation:registercompletion,securityeducation:confirmrequest'),(4,'employee:list,employee:add,employee:update,employee:view,employee:delete'),(4,'help:list,help:view'),(4,'role:list,role:add,role:update,role:view,role:delete'),(4,'equipmentkind:list,equipmentkind:add,equipmentkind:update,equipmentkind:view,equipmentkind:delete'),(4,'securityviolation:list,securityviolation:add,securityviolation:update,securityviolation:view,securityviolation:delete'),(4,'equipment:list,equipment:view,equipment:confirmusage,equipment:confirmtermination'),(5,'securitycheck:list,securitycheck:add,securitycheck:update,securitycheck:view,securitycheck:delete'),(5,'help:list,help:add,help:update,help:view,help:delete'),(5,'securityeducation:list,securityeducation:add,securityeducation:update,securityeducation:view,securityeducation:delete,securityeducation:confirmcompletion'),(5,'employee:list,employee:ad,employee:update,employee:view,employee:delete'),(5,'project:list,project:add,project:update,project:view,project:delete'),(5,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(5,'product:list,product:add,product:update,product:view,product:delete,product:confirm'),(5,'message:list,message:add,message:view,message:delete'),(5,'company:list,company:add,company:update,company:view,company:delete'),(5,'setting:view,setting:update'),(5,'role:list,role:add,role:update,role:view,role:delete'),(5,'equipmentkind:list,equipmentkind:add,equipmentkind:update,equipmentkind:view,equipmentkind:delete'),(5,'employer:list,employer:add,employer:update,employer:view,employer:delete'),(5,'securityviolation:list,securityviolation:add,securityviolation:update,securityviolation:view,securityviolation:delete'),(5,'equipment:list,equipment:view,equipment:confirmusage,equipment:confirmtermination'),(6,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(6,'message:list,message:add,message:view,message:delete'),(6,'employee:list,employee:add,employee:update,employee:view,employee:delete'),(6,'product:list,product:view,product:register'),(6,'help:list,help:view'),(6,'securityviolation:list,securityviolation:doaction,securityviolation:view'),(6,'equipment:list,equipment:add,equipment:update,equipment:view,equipment:delete,equipment:requesttermination'),(6,'securityeducation:list,securityeducation:view,securityeducation:confirmrequest,securityeducation:registercompletion'),(7,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(7,'message:list,message:add,message:view,message:delete'),(7,'help:list,help:view'),(7,'securityviolation:list,securityviolation:doaction,securityviolation:view'),(8,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(8,'message:list,message:add,message:view,message:delete'),(8,'help:list,help:view'),(8,'securityviolation:list,securityviolation:doaction,securityviolation:view'),(9,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(9,'message:list,message:add,message:view,message:delete'),(9,'help:list,help:view'),(9,'securityviolation:list,securityviolation:doaction,securityviolation:view'),(10,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(10,'message:list,message:add,message:view,message:delete'),(10,'help:list,help:view'),(10,'securityviolation:list,securityviolation:doaction,securityviolation:view'),(11,'messagereceiver:list,messagereceiver:view,messagereceiver:delete'),(11,'message:list,message:add,message:view,message:delete'),(11,'help:list,help:view'),(11,'securityviolation:list,securityviolation:doaction,securityviolation:view');
/*!40000 ALTER TABLE `role_power` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_check`
--

DROP TABLE IF EXISTS `security_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_check` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `businessScope` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cycle` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dailyTimes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `details` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `endDate` datetime(6) DEFAULT NULL,
  `inactive` datetime(6) DEFAULT NULL,
  `inspectionTime` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `inspectionTimeHour` int(11) NOT NULL,
  `inspectionTimeMinute` int(11) NOT NULL,
  `inspectionTimeSession` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monthlyDate` int(11) NOT NULL,
  `monthlyEndDate` datetime(6) DEFAULT NULL,
  `monthlyTimes` int(11) NOT NULL,
  `periodDate` datetime(6) DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `round` int(11) NOT NULL,
  `startDate` datetime(6) DEFAULT NULL,
  `targetProject_id` bigint(20) DEFAULT NULL,
  `targetRole` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weeklyDate` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weeklyEndDate` datetime(6) DEFAULT NULL,
  `weeklyTimes` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_check`
--

LOCK TABLES `security_check` WRITE;
/*!40000 ALTER TABLE `security_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_check_history`
--

DROP TABLE IF EXISTS `security_check_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_check_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progressHistory` varchar(35) COLLATE utf8_unicode_ci DEFAULT NULL,
  `securityCheck_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_check_history`
--

LOCK TABLES `security_check_history` WRITE;
/*!40000 ALTER TABLE `security_check_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_check_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_education`
--

DROP TABLE IF EXISTS `security_education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_education` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `approveDate` datetime(6) DEFAULT NULL,
  `approver_id` bigint(20) DEFAULT NULL,
  `completedDate` datetime(6) DEFAULT NULL,
  `cycle` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dailyTimes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `details` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `division` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequency` int(11) NOT NULL,
  `lastRun` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monthlyDate` int(11) NOT NULL,
  `monthlyEndDate` datetime(6) DEFAULT NULL,
  `period` datetime(6) DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `round` int(11) NOT NULL,
  `statusNotification` bit(1) NOT NULL,
  `targetCompany_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weeklyDate` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weeklyEndDate` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_education`
--

LOCK TABLES `security_education` WRITE;
/*!40000 ALTER TABLE `security_education` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_education_history`
--

DROP TABLE IF EXISTS `security_education_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_education_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progressHistory` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `securityEducation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_education_history`
--

LOCK TABLES `security_education_history` WRITE;
/*!40000 ALTER TABLE `security_education_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_education_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_education_target`
--

DROP TABLE IF EXISTS `security_education_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_education_target` (
  `securityEducation_id` bigint(20) NOT NULL,
  `targets` bigint(20) DEFAULT NULL,
  KEY `FK7nugax9aon0991hs56ovbiq8c` (`securityEducation_id`),
  CONSTRAINT `FK7nugax9aon0991hs56ovbiq8c` FOREIGN KEY (`securityEducation_id`) REFERENCES `security_education` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_education_target`
--

LOCK TABLES `security_education_target` WRITE;
/*!40000 ALTER TABLE `security_education_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_education_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_violation`
--

DROP TABLE IF EXISTS `security_violation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_violation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `actionDetails` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `approveDate` datetime(6) DEFAULT NULL,
  `approverName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `approver_id` bigint(20) DEFAULT NULL,
  `followTheInstruction` bit(1) NOT NULL,
  `instruction` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `measureDate` datetime(6) DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statusNotification` bit(1) NOT NULL,
  `targetCompanyName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetCompany_id` bigint(20) DEFAULT NULL,
  `targetEmployeeName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `targetEmployee_id` bigint(20) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `violationContent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_violation`
--

LOCK TABLES `security_violation` WRITE;
/*!40000 ALTER TABLE `security_violation` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_violation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `security_violation_history`
--

DROP TABLE IF EXISTS `security_violation_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `security_violation_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progressHistory` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `securityViolation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_violation_history`
--

LOCK TABLES `security_violation_history` WRITE;
/*!40000 ALTER TABLE `security_violation_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `security_violation_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `storageFolder` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_history`
--

DROP TABLE IF EXISTS `training_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `employee_id` bigint(20) DEFAULT NULL,
  `lastRun` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `progress` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `round` int(11) NOT NULL,
  `securityEducation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_history`
--

LOCK TABLES `training_history` WRITE;
/*!40000 ALTER TABLE `training_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `company_id` bigint(20) DEFAULT NULL,
  `contact` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `department` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `externalIP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `externalIPRequired` bit(1) NOT NULL,
  `fullName` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `haveSecurityPledge` bit(1) NOT NULL,
  `internalIP` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `recentSignIn` datetime(6) DEFAULT NULL,
  `referenceDescription` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_id` bigint(20) DEFAULT NULL,
  `salkey` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `securityViolationHistory` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2018-06-27 06:40:04.675000',NULL,'\0','2018-06-27 06:40:07.359000',1,'',NULL,'','','admin@eazymation.com','','\0','SuperAdmin','\0','','8069f1e557fa4359bd9fdce15a5301ae','2018-06-27 06:40:07.354000','',1,'XP4ppa5szvDXI+NfjeNG+ThM/t9Qv/2p',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_check_history`
--

DROP TABLE IF EXISTS `user_check_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_check_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdDate` datetime(6) DEFAULT NULL,
  `createdPerson_id` bigint(20) DEFAULT NULL,
  `deleted` bit(1) NOT NULL,
  `updatedDate` datetime(6) DEFAULT NULL,
  `updatedPerson_id` bigint(20) DEFAULT NULL,
  `checkDate` datetime(6) DEFAULT NULL,
  `checked` bit(1) NOT NULL,
  `round` int(11) NOT NULL,
  `securityCheck_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_check_history`
--

LOCK TABLES `user_check_history` WRITE;
/*!40000 ALTER TABLE `user_check_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_check_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_do_contract`
--

DROP TABLE IF EXISTS `worker_do_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `worker_do_contract` (
  `user_id` bigint(20) NOT NULL,
  `contract_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`contract_id`),
  KEY `FKiflnx5gh2fqls0ghqjun7detx` (`contract_id`),
  CONSTRAINT `FKg3ec636w48jp39fjf44b2tt39` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKiflnx5gh2fqls0ghqjun7detx` FOREIGN KEY (`contract_id`) REFERENCES `contract` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_do_contract`
--

LOCK TABLES `worker_do_contract` WRITE;
/*!40000 ALTER TABLE `worker_do_contract` DISABLE KEYS */;
/*!40000 ALTER TABLE `worker_do_contract` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-27 13:40:15
